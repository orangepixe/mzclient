<?php

namespace FluxPro;

use Illuminate\Support\Str;

class FluxProManager
{
    //
}
