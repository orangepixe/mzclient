
{!! app('flux')->editorScripts() !!}
